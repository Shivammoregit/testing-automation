# AGENTS.md (Generic) — Petyosa Agentic Workflow

## Commit & Pull Request Guidelines
No history exists yet; use Conventional Commits (e.g., feat:, fix:, docs:).
PRs should describe behavior, list key commands/output, and link issues.
Update README.md/--help text when CLI surfaces change; include before/after examples.

## CRITICAL: Use ripgrep, not grep

NEVER use grep for project-wide searches (slow, ignores .gitignore). ALWAYS use rg.

- `rg "pattern"` — search content
- `rg --files | rg "name"` — find files
- `rg -t python "def"` — language filters

## File finding
- Prefer `fd` (or `fdfind` on Debian/Ubuntu). Respects .gitignore.

## JSON
- Use `jq` for parsing and transformations.

## Install Guidance
- macOS: `brew install ripgrep fd jq`
- Debian/Ubuntu: `sudo apt update && sudo apt install -y ripgrep fd-find jq` (alias fd=fdfind)

## Agent Instructions
- Replace commands: grep→rg, find→rg --files/fd, ls -R→rg --files, cat|grep→rg pattern file
- Cap reads at 250 lines; prefer `rg -n -A 3 -B 3` for context
- Use `jq` for JSON instead of regex
## Env files
- Never edit `.env*` inside repos.
- Env files are copied from `Agentic-Workflow/env/`.
- Follow each repo’s `AGENTS.md` env/script contract.


---


# Context addendum
Update `Context/changes/YYYY-MM.md` with summaries, PR links, and how-to-test.

